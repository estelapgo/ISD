package es.udc.ws.app.model.util;

public class ModelConstants {

    public static final String APP_DATA_SOURCE = "ws-javaexamples-ds";
    public static final double MAX_PRICE = 1000;

}
